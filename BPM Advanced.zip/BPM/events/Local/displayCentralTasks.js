function displayCentralTasks(links) {
	
	links.put("Domine a Central de Tarefas", "http://SPON010108205:8082/portal/p/1/ecmnavigation?app_ecm_navigation_doc=54");
	
}