var products = SuperWidget.extend({
   

    init: function () {
           	
    },

    bindings: {
        local: {
            'consult': ['click_consult']
        }
    },

    consult: function () {
    	
         var cod = $("#cod").val();
         
         
         
        
    	
    	
    	
    }
});